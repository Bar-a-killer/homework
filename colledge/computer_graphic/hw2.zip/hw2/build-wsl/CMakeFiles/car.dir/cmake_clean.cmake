file(REMOVE_RECURSE
  "CMakeFiles/car.dir/car.c.o"
  "CMakeFiles/car.dir/car.c.o.d"
  "car"
  "car.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/car.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
