file(REMOVE_RECURSE
  "CMakeFiles/cubes.dir/cubes.c.o"
  "CMakeFiles/cubes.dir/cubes.c.o.d"
  "cubes"
  "cubes.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/cubes.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
