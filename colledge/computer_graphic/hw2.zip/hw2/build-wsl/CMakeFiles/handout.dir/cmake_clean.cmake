file(REMOVE_RECURSE
  "CMakeFiles/handout.dir/handout.cpp.o"
  "CMakeFiles/handout.dir/handout.cpp.o.d"
  "handout"
  "handout.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang CXX)
  include(CMakeFiles/handout.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
