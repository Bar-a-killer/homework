file(REMOVE_RECURSE
  "CMakeFiles/wind_mill.dir/wind_mill.c.o"
  "CMakeFiles/wind_mill.dir/wind_mill.c.o.d"
  "wind_mill"
  "wind_mill.pdb"
)

# Per-language clean rules from dependency scanning.
foreach(lang C)
  include(CMakeFiles/wind_mill.dir/cmake_clean_${lang}.cmake OPTIONAL)
endforeach()
