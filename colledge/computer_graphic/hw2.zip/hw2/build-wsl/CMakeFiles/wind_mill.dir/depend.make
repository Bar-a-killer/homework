# Empty dependencies file for wind_mill.
# This may be replaced when dependencies are built.
